#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <limits>
using namespace std;

struct Student {
    string name;
    int grade;
};

void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int readIntInRange(const string &prompt, int minVal, int maxVal) {
    int value;
    while (true) {
        cout << prompt;
        if (!(cin >> value)) {
            clearInput();
            continue;
        }
        if (value < minVal || value > maxVal) {
            clearInput();
            continue;
        }
        clearInput();
        return value;
    }
}

string readNonEmptyLine(const string &prompt) {
    string input;
    while (true) {
        cout << prompt;
        getline(cin, input);
        if (!input.empty())
            return input;
    }
}

void showMenu() {
    cout << "\n=====================================\n";
    cout << " Mini Student Gradebook (Unit Project 1)\n";
    cout << "=====================================\n";
    cout << "1) Counter-controlled entry\n";
    cout << "2) Sentinel-controlled entry\n";
    cout << "3) Display results\n";
    cout << "4) Clear all student data\n";
    cout << "0) Exit\n";
    cout << "-------------------------------------\n";
}

// fixed number of students
void counterControlledEntry(vector<Student> &students) {
    cout << "\n--- Counter-Controlled Entry ---\n";
    int count = readIntInRange("How many students? ", 1, 50);

    for (int i = 0; i < count; i++) {
        string name = readNonEmptyLine("Enter student name: ");
        int grade = readIntInRange("Enter grade (0-100): ", 0, 100);
        students.push_back({name, grade});
        cout << "Student added successfully!\n";
    }
}

// Allows the user to add as many as they please
void sentinelControlledEntry(vector<Student> &students) {
    cout << "\n--- Sentinel-Controlled Entry ---\n";

    while (true) {
        string name = readNonEmptyLine("Enter student name (STOP to finish): ");
        if (name == "STOP")
            break;

        int grade = readIntInRange("Enter grade (0-100): ", 0, 100);
        students.push_back({name, grade});
        cout << "Student added successfully!\n";
    }
}

bool computeStats(const vector<Student> &students, double &avg, Student &highest, Student &lowest) {
    if (students.empty())
        return false;

    double total = 0.0;
    highest = students[0];
    lowest = students[0];

    for (const Student &s : students) {
        total += s.grade;
        if (s.grade > highest.grade)
            highest = s;
        if (s.grade < lowest.grade)
            lowest = s;
    }

    avg = total / students.size();
    return true;
}

void displayResults(const vector<Student> &students) {
    cout << "\n--- Gradebook Results ---\n";

    if (students.empty()) {
        cout << "You have no students.\n";
        return;
    }

    double avg;
    Student highest;
    Student lowest;

    // calls computestats()
    if (!computeStats(students, avg, highest, lowest))
        return;

    // summary
    cout << "Total students: " << students.size() << endl;
    cout << fixed << setprecision(1);
    cout << "Average grade: " << avg << endl;
    cout << "Highest: " << highest.name << " / " << highest.grade << endl;
    cout << "Lowest : " << lowest.name << " / " << lowest.grade << endl;

    // iomanip table
    cout << "\n";
    cout << left << setw(20) << "Name"
         << setw(10) << "Grade"
         << setw(10) << "Status" << endl;

    cout << string(40, '-') << endl;

    for (const Student &s : students) {
        cout << left << setw(20) << s.name
             << setw(10) << s.grade
             << setw(10) << (s.grade >= 60 ? "Pass" : "Fail")
             << endl;
    }
}

int main() {
    vector<Student> students;
    int choice = -1;

    while (choice != 0) {
        showMenu();
        cout << "Choice: ";

        if (!(cin >> choice)) {
            clearInput();
            continue;
        }

        clearInput();

        switch (choice) {
            case 1:
                counterControlledEntry(students);
                break;
            case 2:
                sentinelControlledEntry(students);
                break;
            case 3:
                displayResults(students);
                break;
            case 4:
                students.clear();
                cout << "All student data cleared.\n";
                break;
            case 0:
                cout << "Goodbye!\n";
                break;
            default:
                break;
        }
    }

    return 0;
}
